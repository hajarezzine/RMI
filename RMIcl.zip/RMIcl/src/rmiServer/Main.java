package rmiServer;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {
		// TODO Auto-generated method stub
		RmiTraitement carnet = (RmiTraitement) Naming.lookup("rmi://localhost:1215/RMI" );
		  Scanner scanner = new Scanner(System.in);
		  while (true) {
              System.out.println("\n1. Ajouter Contact\n2. Supprimer Contact\n3. Rechercher Contact\n4. Lister Contacts\n5. Quitter");
              System.out.print("Choix : ");
              int choix = scanner.nextInt();
              scanner.nextLine();  

              switch (choix) {
                  case 1:
                      System.out.print("Nom : ");
                      String nom = scanner.nextLine();
                      System.out.print("Téléphone : ");
                      String telephone = scanner.nextLine();
                      System.out.print("Email : ");
                      String email = scanner.nextLine();
                      carnet.ajouterContact(nom, telephone, email);
                      break;
                  case 2:
                      System.out.print("Nom du contact à supprimer : ");
                      carnet.supprimerContact(scanner.nextLine());
                      break;
                  case 3:
                      System.out.print("Nom du contact à rechercher : ");
                      System.out.println(carnet.rechercherContact(scanner.nextLine()));
                      break;
                  case 4:
                      List<String> contacts = carnet.listerContacts();
                      System.out.println("\nContacts : ");
                      contacts.forEach(System.out::println);
                      break;
                  case 5:
                      System.out.println("Au revoir !");
                      System.exit(0);
              }
          }
	}

}
