package rmiServer;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface RmiTraitement extends Remote {
	  void ajouterContact(String nom, String telephone, String email) throws RemoteException;
	    void supprimerContact(String nom) throws RemoteException;
	    String rechercherContact(String nom) throws RemoteException;
	    List<String> listerContacts() throws RemoteException;
}
