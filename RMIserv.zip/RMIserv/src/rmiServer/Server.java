package rmiServer;

import java.net.MalformedURLException;
import java.rmi.*;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
 
public class Server {
	public static void main(String[] args) throws RemoteException, MalformedURLException {
		
		LocateRegistry.createRegistry(1215);
		RmiTraitementimpl rmi = new RmiTraitementimpl() ;
		Naming.rebind("rmi://localhost:1215/RMI", rmi);
		 	System.out.println(rmi.toString());
		 
		 
	}
}
