  package rmiServer;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;


public class RmiTraitementimpl  extends UnicastRemoteObject  implements RmiTraitement {

	private List<String> contacts;

	

	protected RmiTraitementimpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
        contacts = new ArrayList<>();
	}

    

    @Override
    public void ajouterContact(String nom, String telephone, String email) throws RemoteException {
        contacts.add(nom + " - " + telephone + " - " + email);
        System.out.println("Contact ajouté : " + nom);
    }

    @Override
 
    public void supprimerContact(String nom) throws RemoteException {
        for (String contact : contacts) {
            if (contact.startsWith(nom + " -")) {
                contacts.remove(contact);
                System.out.println("Contact supprimé : " + nom);
                return; // On arrête dès que le contact est trouvé et supprimé
            }
        }
        System.out.println("Aucun contact trouvé à supprimer pour : " + nom);
    }


    @Override
 
    public String rechercherContact(String nom) throws RemoteException {
        for (String contact : contacts) {
            if (contact.startsWith(nom + " -")) {
                return contact;  // Retourne immédiatement le contact trouvé
            }
        }
        return "Aucun contact trouvé.";  // Si aucun contact n'est trouvé, on retourne ce message
    }

    @Override
    public List<String> listerContacts() throws RemoteException {
        return contacts;
    }

}
